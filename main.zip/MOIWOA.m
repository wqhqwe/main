function Best_MOIWOA = MOIWOA(Parent,time,cost,nPop,maxIt,template,Smin,Smax,num_tasks)
    VarMin = 1;       
    VarMax = 5;      
    Exponent = 3;          
    sigma_initial = 0.8;    
    sigma_final = 0.15;	 
    Best_MOIWOA = zeros(maxIt, 1);

    for it = 1:maxIt

        sigma = ((maxIt - it)/(maxIt - 1))^Exponent * (sigma_initial - sigma_final) + sigma_final;

      Costs = [Parent.Rank];
     BestCost = min(Costs);
     WorstCost = max(Costs);

        newpop = [];

        for i = 1:numel(Parent)
            ratio = (Parent(i).Rank - WorstCost)/(BestCost - WorstCost);
            S = floor(Smin + (Smax - Smin)*ratio); 
            for j = 1:S

                newsol = template;

                newsol.x = Parent(i).x + sigma * randn([num_tasks 1]);
                                                                            
                newsol.x = max(newsol.x, VarMin);
                newsol.x = min(newsol.x, VarMax);     
                 newsol.x = round( newsol.x);   
                newsol.Obj = MOP4(newsol.x, time ,cost);
                newpop = [newpop
                          newsol]; 
            end    
        end
        Parent = [Parent
               newpop];

   [Parent, F2] = Non_Dominate_Sort(Parent);

    Parent = Cal_crowdingdistance(Parent, F2);

    Parent = Multi_Sort(Parent);

    Parent = Parent(1:nPop);

    [Parent, F2] = Non_Dominate_Sort(Parent);

    Parent = Cal_crowdingdistance(Parent, F2);

    Parent = Multi_Sort(Parent);

    Best_MOIWOA = [Parent.Obj];

end
