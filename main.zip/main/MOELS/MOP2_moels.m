function z=MOP2_moels(x, time, cost)
    n = numel(x);
    machine_time = zeros(size(time,1),1);
    for i = 1:n
        machine_index = x(i);
        task_time = time(machine_index,i);
        machine_time(machine_index) =  machine_time(machine_index)+task_time;
    end
  
    machine_cost = 0;
    for i = 1:n
        machine_cost = machine_cost + cost(x(i),i);
    end
    z = [max(machine_time); machine_cost]; 
end