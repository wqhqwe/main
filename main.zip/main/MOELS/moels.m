function Best_MOELS = moels(Parent,time,cost,nPop,MaxIt,num_vm,num_tasks)

VarMin = 1;
VarMax = num_vm;
nVar = num_tasks;
VarSize = [nVar 1];
p = round(unifrnd(VarMin,VarMax,VarSize));

nArchive=50;   
nGrid=5;     
InflationFactor=0.1;    
beta_deletion=1; 
beta_selection=2; 

pCrossover=0.1; 
nCrossover=round(pCrossover*nPop/2)*2;  

pMutation=0.01; 
nMutation=floor(nPop*pMutation);  

crossover_params.gamma=0.15; 
crossover_params.VarMin=VarMin; 
crossover_params.VarMax=VarMax; 

mutation_params.h=0.01;  
mutation_params.VarMin=VarMin;  
mutation_params.VarMax=VarMax;  


empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.IsDominated=[];
empty_individual.GridIndex=[];

 pop=repmat(empty_individual,nPop,1);
for i=1:nPop

     pop(i).Position = Parent(i).x;
     pop(i).Cost = Parent(i).Obj;
end

archive=[];


for it=1:MaxIt
   
    pop=DetermineDomination(pop);
    
    ndpop=pop(~[pop.IsDominated]);
    
    archive=[archive
             ndpop]; 
    
    archive=DetermineDomination_moels(archive);
    
    archive=archive(~[archive.IsDominated]);
    [archive, grid]=CreateGrid(archive,nGrid,InflationFactor);
    
    if numel(archive)>nArchive
        E=numel(archive)-nArchive;
        archive=TruncatePopulation(archive,grid,E,beta_deletion);
        [archive, grid]=CreateGrid(archive,nGrid,InflationFactor);
    end
    
    PF=archive;
   
    Best_MOELS=[PF.Cost];


    if it>=MaxIt
        break;
    end
    
    popc=repmat(empty_individual,nCrossover/2,2);
    for c=1:nCrossover/2
        
        p1=SelectFromPopulation(archive,grid,beta_selection);
        p2=SelectFromPopulation(archive,grid,beta_selection);
        
        [popc(c,1).Position, popc(c,2).Position]=Crossover(p1.Position,...
                                                           p2.Position,...
                                                           crossover_params);
        
                                                       
        popc(c,1).Position = round(popc(c,1).Position);
        popc(c,2).Position = round(popc(c,2).Position);
        popc(c,1).Cost=MOP2_moels(popc(c,1).Position,time,cost);
        
        popc(c,2).Cost=MOP2_moels(popc(c,2).Position,time,cost);
        
    end
    popc=popc(:);

    popm=repmat(empty_individual,nMutation,1);
    for m=1:nMutation
        
        p=SelectFromPopulation(archive,grid,beta_selection);
        
        popm(m).Position=Mutate(p.Position,mutation_params);
        
        popm(m).Position = round(popm(m).Position);
        popm(m).Cost=MOP2_moels(popm(m).Position,time,cost);
        
    end
    
    pop=[popc
         popm];
         
end
