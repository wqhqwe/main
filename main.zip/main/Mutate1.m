function y = Mutate1(p, n)
 
       x = p;
    m = numel(p);
    s1 = randi([1, m]);
    s2 = randi([1, n]);
    x(s1) = s2;
    y = x;
end