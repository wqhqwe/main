function Best_NSGA2 = DNSGA(time,cost,nPop,n,maxIt,template,Parent,mu)
    for It = 1 : maxIt
        Offspring = repmat(template, nPop/2, 2); 
        for j = 1 : nPop / 2     
           ind = randperm(nPop);
            [Offspring(j, 1).x, Offspring(j, 2).x] = ...
                crossP(Parent(ind(1)).x,Parent(ind(2)).x);
        end
        Offspring = Offspring(:);
        for k = 1 :nPop
            Offspring(k).x = Mutate2(Parent(k).x, n, mu);
            Offspring(k).Obj = MOP4(Offspring(k).x, time ,cost);  
        end
   newpop = [Parent;Offspring];   
   [newpop, F] = Non_Dominate_Sort(newpop);
    newpop = Cal_crowdingdistance(newpop, F);
    newpop = Multi_Sort(newpop);
    Parent = newpop(1:nPop);
    [Parent, F] = Non_Dominate_Sort(Parent);
    Parent = Cal_crowdingdistance(Parent, F);
    Parent = Multi_Sort(Parent);
    Best_NSGA2 = [Parent.Obj];
    end

