function pop = Cal_crowdingdistance(pop, F)
    nF = numel(F); 
    for k = 1 : nF
        Objs = [pop(F{k}).Obj]; 
        nObj = size(Objs, 1); 
        n = numel(F{k}); 
        d = zeros(n, nObj); 
        for j = 1 : nObj
            [obj, ind] = sort(Objs(j,:), 'ascend'); 
            d(ind(1), j) = inf; 
            for i = 2 : n - 1
                d(ind(i), j) = abs(obj(i+1) - obj(i-1))/abs(obj(1) - obj(end));
            end
            d(ind(end), j) = inf;  
        end
        for i = 1 : n
            pop(F{k}(i)).CrowdingDistance = sum(d(i, :));
        end
    end
end