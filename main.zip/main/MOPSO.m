function Best_PSO = MOPSO(Parent,time,cost,nPop,maxIt,num_tasks)
    limit = [1, 5];               
    vlimit = [-1, 1];               
    w = 0.5;                       
    c1 = 5;                       
    c2 = 5;                       


    x = zeros(num_tasks,nPop); 
    px = zeros(num_tasks, 1);    
    y = ones(nPop, 1)*inf;  
    py = inf;             

    for i = 1 : nPop  
        Parent(i).z = randi([-1,1], num_tasks, 1); 
        x(:, i) = Parent(i).x;  
        
        if Parent(i).Rank < y(i)
            y(i) = Parent(i).Rank ;     
            x(:, i) = Parent(i).x;   
        end

        if  min(y)  < py
            [py, nmin] = min(y);   
            px = x(:,nmin);      
        end  
    end
    for It = 1 : maxIt
         for i = 1:nPop  
             Parent(i).z = Parent(i).z * w + c1 * rand * (x(:, i) - Parent(i).x) + c2 * rand * (px - Parent(i).x); 
             Parent(i).z(Parent(i).z > vlimit(2)) = vlimit(2);  
             Parent(i).z(Parent(i).z < vlimit(1)) = vlimit(1);
             Parent(i).x = Parent(i).x + Parent(i).z ;
             Parent(i).x(Parent(i).x > limit(2)) = limit(2);  
             Parent(i).x(Parent(i).x < limit(1)) = limit(1);  
             Parent(i).x = round(Parent(i).x);

             Parent(i).Obj = MOP4(Parent(i).x, time ,cost);

             [Parent, F] = Non_Dominate_Sort(Parent);

             Parent = Cal_crowdingdistance(Parent, F);
         end
         for i = 1:nPop
            if Parent(i).Rank < y(i) 
                y(i) = Parent(i).Rank ;  
                x(:, i) = Parent(i).x;   
            end   
         end
         if  min(y)  < py
             [py, nmin] = min(y);   
             px = x(:,nmin);     
         end 

        Parent = Multi_Sort(Parent);

        Best_PSO = [Parent.Obj];

         Objs = [Parent.Obj];
        clf
        plot(Objs(1,:),Objs(2,:),'r*', 'MarkerSize', 8);
        hold on;

        xlabel('ʱ��');
        ylabel('�ɱ�');
        title('��Ŀ���Ż�');
        grid on;
        pause(0.01);
        disp(['��ǰ��������',num2str(It)]);      
    end  

end