function p = selectPop3(Parent)
    F=0;
    p1 = zeros(1,length(Parent));
    p2 = zeros(1,length(Parent));
    for i=1:length(Parent)
        F= 1/Parent(i).Rank + F;
    end
    for i=1:length(Parent)
        p1(i)=(1/Parent(i).Rank)/F;
    end

    for i=1:length(Parent)
        for j=1:i
            p2(i)=p2(i)+p1(j);
        end
    end
    r = rand;
    for i =1:length(Parent)
        if p2(i) >=r
            p = Parent(i);
            break;
        end
    end
end