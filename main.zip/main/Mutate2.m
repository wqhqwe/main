function y = Mutate2(p, n, mu)
      x = p;
    if rand <= mu  
        m = numel(p);
        s1 = randi([1, m]);
        s2 = randi([1, n]);
        x(s1) = s2;
    end
    y = x;

end