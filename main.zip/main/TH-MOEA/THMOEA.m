function Best_MOEA = THMOEA(Parent,time,cost,nPop,MaxIt,num_vm,num_tasks)

VarMin = 1;
VarMax = num_vm;
nVar = num_tasks;
VarSize = [nVar 1];
p = round(unifrnd(VarMin,VarMax,VarSize));
nObj=numel(MOP2(p,time,cost));

nArchive=50;

T=max(ceil(0.15*nPop),2);    
T=min(max(T,2),15);       


crossover_params.gamma=0.5; 
crossover_params.VarMin=VarMin;
crossover_params.VarMax=VarMax;

sp=CreateSubProblems(nObj,nPop,T);

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.g=[];
empty_individual.IsDominated=[];

z=zeros(nObj,1);


pop=repmat(empty_individual,nPop,1);
for i=1:nPop

    pop(i).Position = Parent(i).x;
    pop(i).Cost = Parent(i).Obj;
    z=min(z,pop(i).Cost);
end

for i=1:nPop
    pop(i).g=DecomposedCost(pop(i),z,sp(i).lambda);
end

pop=DetermineDomination(pop);

EP=pop(~[pop.IsDominated]); 

for it=1:MaxIt
    for i=1:nPop
        K=randsample(T,2);
        
        j1=sp(i).Neighbors(K(1));
        p1=pop(j1);
        
        j2=sp(i).Neighbors(K(2));
        p2=pop(j2);
        
        y=empty_individual;
        y.Position=Crossover(p1.Position,p2.Position,crossover_params);

        y.Cost = MOP2(p,time,cost);
        z=min(z,y.Cost);
        
        for j=sp(i).Neighbors 
            y.g=DecomposedCost(y,z,sp(j).lambda);
            if y.g<=pop(j).g 
                pop(j)=y;
            end
        end   
    end
    
	pop=DetermineDomination(pop);  
    ndpop=pop(~[pop.IsDominated]);
    EP=[EP
        ndpop]; 
   
    EP=DetermineDomination(EP);
    EP=EP(~[EP.IsDominated]);
    
    if numel(EP)>nArchive
        Extra=numel(EP)-nArchive;
        ToBeDeleted=randsample(numel(EP),Extra);
        EP(ToBeDeleted)=[];
    end
    

    Best_MOEA = [EP.Cost];
    
end
