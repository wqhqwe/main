clc;clear;close all
nPop = 50; 
num_tasks = 100;  
num_vm = 5; 
maxIt = 500; 
mu = 0.01;   


addpath('D:\matlab\data\main\MOELS');
addpath('D:\matlab\data\main\TH-MOEA');

speed = [800, 1600, 3200, 6400, 12800]; 
bandwidth = [0.01, 0.02, 0.03, 0.04, 0.05]; 
Mem = [0.01, 0.02, 0.03, 0.04, 0.05];
price = [1, 2, 4, 8, 16]; 


length = randi([50, 50000], 1, num_tasks); 
input_size = randi([50, 200], 1, num_tasks); 
output_size = randi([50, 200], 1, num_tasks);
RM = randi([10, 100], 1, num_tasks);

time = zeros(num_vm, num_tasks);
cost = zeros(num_vm, num_tasks);

for i = 1:num_vm
    for j = 1:num_tasks
        time(i, j) = length(j) ./ speed(i);
        cost(i, j)  =  time(i, j) * price(i) + ...
            (input_size(j) + output_size(j)) * bandwidth(i)+...
            Mem(i)*RM(j);
    end
end

template.x = [];
template.Obj= [];
template.DominantSet = [];
template.Dominated = 0;
template.Rank = 0;
template.CrowdingDistance = [];

template.z = []; 

Parent = repmat(template, nPop, 1);

for i = 1 : nPop
    Parent(i).x = randi([1 num_vm], num_tasks, 1);
    Parent(i).Obj = MOP4(Parent(i).x, time ,cost);
end
    [Parent, F] = Non_Dominate_Sort(Parent); 
    Parent = Cal_crowdingdistance(Parent, F);
    Parent = Multi_Sort(Parent);

   Best_IWOGA = IWO_GA11(Parent,time,cost,nPop,maxIt,template,num_vm);
   Best_MOELS = moels(Parent,time,cost,nPop,maxIt,num_vm,num_tasks);
   Best_MOEA = THMOEA(Parent,time,cost,nPop,maxIt,num_vm,num_tasks);
   Best_NSGA2 = DNSGA(time,cost,nPop,num_vm,maxIt,template,Parent,mu);
   % Best_PSO = MOPSO(Parent,time,cost,nPop,maxIt,num_tasks);

   x = 1:maxIt;
     clf
     plot(Best_IWOGA(1,:),Best_IWOGA(2,:),'b*', 'MarkerSize', 8);   
      hold on;
      plot(Best_MOELS(1,:),Best_MOELS(2,:),'r*', 'MarkerSize', 8);
      plot(Best_MOEA(1,:),Best_MOEA(2,:),'g*', 'MarkerSize', 8);
      plot(Best_NSGA2(1,:),Best_NSGA2(2,:),'k*', 'MarkerSize', 8);
      xlabel('Makespan');
      ylabel('Cost');
    legend('GA-IWOA', 'MOELS', 'TH-MOEA','DNSGA-��'); 
    lastValue1 = Best_IWOGA(end);
    lastValue2 = Best_MOELS(end);
    lastValue3 = Best_MOEA(end);
    lastValue5 = Best_NSGA2(end);

BMakespan = max([Best_IWOGA(1,:), Best_MOELS(1,:), Best_MOEA(1,:), Best_NSGA2(1,:)]);
BCost = max([Best_IWOGA(2,:), Best_MOELS(2,:), Best_MOEA(2,:), Best_NSGA2(2,:)]);
CMakespan = min([Best_IWOGA(1,:), Best_MOELS(1,:), Best_MOEA(1,:), Best_NSGA2(1,:)]);
CCost = min([Best_IWOGA(2,:), Best_MOELS(2,:), Best_MOEA(2,:), Best_NSGA2(2,:)]);

ref_point = [BMakespan, BCost];  

P_IWOA(1, :) = Best_IWOGA(1, :) / BMakespan;
P_IWOA(2, :) = Best_IWOGA(2, :) / BCost;

P_THMOEA(1, :) = Best_MOELS(1, :) / BMakespan;
P_THMOEA(2, :) = Best_MOELS(2, :) / BCost;

P_MOELS(1, :) = Best_MOEA(1, :) / BMakespan;
P_MOELS(2, :) = Best_MOEA(2, :) / BCost;

P_DNSGA(1, :) = Best_NSGA2(1, :) / BMakespan;
P_DNSGA(2, :) = Best_NSGA2(2, :) / BCost;


[~, sorted_indices] = sort(Best_IWOGA(1,:), 'descend');
Best_IWOGA = Best_IWOGA(:, sorted_indices);

[~, sorted_indices] = sort(Best_MOELS(1,:), 'descend');
Best_MOELS = Best_MOELS(:, sorted_indices);

[~, sorted_indices] = sort(Best_MOEA(1,:), 'descend');
Best_MOEA = Best_MOEA(:, sorted_indices);

[~, sorted_indices] = sort(Best_NSGA2(1,:), 'descend');
Best_NSGA2 = Best_NSGA2(:, sorted_indices);

HV_IWOGA = hypervolume2d(Best_IWOGA, ref_point)/((BMakespan-CMakespan)*(BCost-CCost));  
HV_THMOEA = hypervolume2d(Best_MOELS, ref_point)/((BMakespan-CMakespan)*(BCost-CCost));  
HV_MOELS = hypervolume2d(Best_MOEA, ref_point)/((BMakespan-CMakespan)*(BCost-CCost));  
HV_DNSGA = hypervolume2d(Best_NSGA2, ref_point)/((BMakespan-CMakespan)*(BCost-CCost));  

disp("=======================================");
 disp(HV_IWOGA);
disp(HV_THMOEA);
disp(HV_MOELS);
disp(HV_DNSGA);

function hv = hypervolume2d(front, ref)
    hv = 0;
    prev_M = ref(1);  


    for i = 1:length(front)
        dx = prev_M - front(1,i);        
        dy = ref(2) - front(2,i);        
        hv = hv + dx * dy;
        prev_M = front(1,i);            
    end
end

% filename = 'data.xlsx'; 
% 
% % data = {"200"," "," "," "," "," "," "," "," "," "," "," "," "," ";
% %     "GA-IWOA"," "," ","TH-MOEA"," "," ","MOELS"," "," ","SPEA"," "," ","DNSGA2"," ";
% %          "Makespan","Cost"," ","Makespan","Cost"," ","Makespan","Cost"," ","Makespan","Cost"," ","Makespan","Cost";
% %          num2str(min(Best_IWOGA(1,:))),num2str(max(Best_IWOGA(2,:)))," ",...
% %          num2str(min(Best_MOELS(1,:))),num2str(max(Best_MOELS(2,:)))," ",...
% %          num2str(min(Best_MOEA(1,:))),num2str(max(Best_MOEA(2,:)))," ",...
% %          num2str(min(Best_SPEA(1,:))),num2str(max(Best_SPEA(2,:)))," ",...
% %          num2str(min(Best_NSGA2(1,:))),num2str(max(Best_NSGA2(2,:)));}
% 
% data = {num2str(min(Best_IWOGA(1,:))),num2str(max(Best_IWOGA(2,:)))," ",...
%          num2str(min(Best_PESA(1,:))),num2str(max(Best_PESA(2,:)))," ",...
%          num2str(min(Best_MOEA(1,:))),num2str(max(Best_MOEA(2,:)))," ",...
%          num2str(min(Best_SPEA(1,:))),num2str(max(Best_SPEA(2,:)))," ",...
%          num2str(min(Best_NSGA2(1,:))),num2str(max(Best_NSGA2(2,:)));}
% 
% if exist(filename, 'file') == 2
%     writecell(data, filename, 'WriteMode', 'append');
% else
%     writecell(data, filename);
% end
% disp('�����ѳɹ�׷�ӵ�Excel�ļ���');

set(gcf,'color','white');
set(gca, 'FontWeight', 'bold')

exportsetupdlg();
