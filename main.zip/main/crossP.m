function [new_x,new_y] = crossP(x,y)
    n = numel(x); 
    s = randi([1, n - 1]); 

    x1 = x(1 : s);
    x2 = x(s + 1: end);
    y1 = y(1 : s);
    y2 = y(s + 1: end);
    new_x = [x1;y2];
    new_y = [y1;x2];



end