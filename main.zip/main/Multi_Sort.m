function pop = Multi_Sort(pop)
    [~, ind_cd] = sort([pop.CrowdingDistance], 'descend');
    pop = pop(ind_cd);
    [~,ind_Rank] = sort([pop.Rank],'ascend');
    pop = pop(ind_Rank);
end
