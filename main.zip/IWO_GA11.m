function Best_IWOGA = IWO_GA11(Parent,time,cost,nPop,maxIt,template,num_vm,num_tasks)
    Smin = 0;      
    Smax = 5;       
    for It = 1 : maxIt
        Costs = [Parent.Rank];
        BestCost = min(Costs);
        WorstCost = max(Costs);

        Offspring = repmat(template, nPop/2, 2); 
        for j = 1 : nPop / 2        

             p1 = selectPop3(Parent);
             p2 = selectPop3(Parent); 

            [Offspring(j, 1).x, Offspring(j, 2).x] = crossP(p1.x, p2.x);
            Offspring(j, 1).Obj = MOP4(Offspring(j, 1).x, time ,cost);
            Offspring(j, 2).Obj = MOP4(Offspring(j, 2).x, time ,cost);
        end

        Offspring = Offspring(:);

        popm2 = [];
       for k = 1 :nPop

                ratio = (Parent(k).Rank - WorstCost)/(BestCost - WorstCost);
                S = floor(Smin + (Smax - Smin)*ratio); 
                for j = 1:S
                     Offspring2 = template;
                     Offspring2.x =  Parent(k).x + sigma * randn([num_tasks 1]);
                     Offspring2.x = max(Offspring2.x, VarMin);
                     Offspring2.x = min(Offspring2.x, VarMax);     
                     Offspring2.x = round(Offspring2.x);     
                     Offspring2.Obj = MOP4(Offspring2.x, time ,cost);
                     popm2 = [popm2 Offspring2];
                end

        end
   popm2 = popm2(:);   

   newpop2 = [Parent;Offspring;popm2];

   [newpop2, F2] = Non_Dominate_Sort(newpop2);

    newpop2 = Cal_crowdingdistance(newpop2, F2);

    newpop2 = Multi_Sort(newpop2);

    Parent = newpop2(1:nPop);

    [Parent, F2] = Non_Dominate_Sort(Parent);

    Parent = Cal_crowdingdistance(Parent, F2);

    Parent = Multi_Sort(Parent);

    Best_IWOGA = [Parent.Obj];

    end

end